# Glossary of Acronyms

EPD
:   Electrophoretic Display (e-Paper Display)

EPD Panel
:   EPD

EPD Module
:   EPD with TCon board

TCon
:   Timing Controller

TFT
:   Thin Film Transistor

MCU
:   Microcontroller Unit

FPC
:   Flexible Printed Circuit

FPL
:   Front Plane Laminate

SPI
:   Serial Peripheral Interface

COG
:   Chip on Glass

PCS
:   Print Contrast Signal

PDI
:   Pervasive Displays Incorporated