from distutils.core import setup

setup(name='EPD',
  version='0.1',
  py_modules=['EPD'],
  package_dir = {'': 'PlatformWithOS/demo'},
  )
