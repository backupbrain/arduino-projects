# Simple barcode demo

most files came from:

http://code.activestate.com/recipes/426069-ean-bar-code-image-generator/

Run the program from this directory, but ensure the EPD.py is on the PYTHONPATH

The following command is sufficient:
~~~
% PYTHONPATH=.. python BarCodeDemo.py
~~~
