// dummy file for Arduino library detection
