# Copyright

** © Copyright Pervasive Displays Incorporated.**

![This work is licensed under a [Creative Commons Attribution-ShareAlike 4.0 Unported License](http://creativecommons.org/licenses/by-sa/4.0/deed.en_US).](images/common/cc-by-sa.svg)